<?php

namespace Plugin\SlnPayment42;

class SlnException extends \Exception
{
}