<?php

namespace Plugin\SlnPayment42\Service\SlnAction\Content\Credit\Response;

class Delete extends Capture
{
   
}