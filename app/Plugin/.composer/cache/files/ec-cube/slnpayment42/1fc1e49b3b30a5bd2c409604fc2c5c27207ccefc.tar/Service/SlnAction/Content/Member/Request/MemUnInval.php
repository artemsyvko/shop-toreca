<?php

namespace Plugin\SlnPayment42\Service\SlnAction\Content\Member\Request;

class MemUnInval extends MemInval
{
}