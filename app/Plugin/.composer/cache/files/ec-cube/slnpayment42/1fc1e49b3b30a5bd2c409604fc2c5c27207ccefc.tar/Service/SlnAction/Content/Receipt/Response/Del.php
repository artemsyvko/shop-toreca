<?php

namespace Plugin\SlnPayment42\Service\SlnAction\Content\Receipt\Response;

class Del extends Chg
{
    
}