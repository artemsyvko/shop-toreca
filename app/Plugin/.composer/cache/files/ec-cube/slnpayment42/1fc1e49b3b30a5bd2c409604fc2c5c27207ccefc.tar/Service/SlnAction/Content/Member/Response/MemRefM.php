<?php

namespace Plugin\SlnPayment42\Service\SlnAction\Content\Member\Response;

class MemRefM extends MemRef
{
}