<?php

return [
    'Names' => [
        'GNF' => [
            0 => 'FG',
            1 => 'GNF',
        ],
    ],
];
