<?php

return [
    'Names' => [
        'MOP' => [
            0 => 'MOP$',
            1 => '澳門元',
        ],
    ],
];
