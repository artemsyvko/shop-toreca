<?php

return [
    'Names' => [
        'JMD' => [
            0 => '$',
            1 => 'Jamaican Dollar',
        ],
    ],
];
