<?php

return [
    'Names' => [
        'MUR' => [
            0 => 'Rs',
            1 => 'Mauritian Rupee',
        ],
    ],
];
