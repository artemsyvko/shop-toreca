<?php

return [
    'Names' => [
        'STN' => [
            0 => 'Db',
            1 => 'dobra de São Tomé e Príncipe',
        ],
    ],
];
