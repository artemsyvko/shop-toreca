<?php

return [
    'Names' => [
        'BWP' => [
            0 => 'P',
            1 => 'Botswanan Pula',
        ],
    ],
];
