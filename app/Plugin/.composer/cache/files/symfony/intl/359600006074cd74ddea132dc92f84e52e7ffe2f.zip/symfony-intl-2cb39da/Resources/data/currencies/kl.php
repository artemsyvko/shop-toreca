<?php

return [
    'Names' => [
        'DKK' => [
            0 => 'kr.',
            1 => 'DKK',
        ],
        'EUR' => [
            0 => '€',
            1 => 'euro',
        ],
    ],
];
