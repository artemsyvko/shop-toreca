<?php

return [
    'Names' => [
        'SZL' => [
            0 => 'E',
            1 => 'Swazi Lilangeni',
        ],
    ],
];
