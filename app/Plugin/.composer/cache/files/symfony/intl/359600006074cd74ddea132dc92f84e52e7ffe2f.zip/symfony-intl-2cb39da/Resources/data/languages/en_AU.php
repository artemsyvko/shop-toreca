<?php

return [
    'Names' => [
        'bn' => 'Bengali',
    ],
    'LocalizedNames' => [
        'en_US' => 'United States English',
        'ro_MD' => 'Moldovan',
    ],
];
