<?php

return [
    'Names' => [
        'XAF' => [
            0 => 'FCFA',
            1 => 'franco CFA de África Central',
        ],
    ],
];
