<?php

return [
    'Names' => [
        'FRF' => [
            0 => 'F',
            1 => 'franc francès',
        ],
    ],
];
