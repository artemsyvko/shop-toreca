<?php

if (\PHP_VERSION_ID >= 80100) {
    return;
}

/** @internal */
class ReflectionEnum
{
    public function __construct($enum)
    {
    }
}

