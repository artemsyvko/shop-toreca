<?php

namespace Laminas\Code\Reflection\Exception;

use Laminas\Code\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
