<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Use Facebook\WebDriver\Exception\NoSuchAlertException
 */
class NoAlertOpenException extends NoSuchAlertException
{
}
